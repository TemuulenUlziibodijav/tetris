/*
Author: 
Date: 
Desc:  
*/

const express = require('express');
const mongoose = require('mongoose');
const parser = require('body-parser');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');

const app = express();
app.use(parser.json());
app.use(parser.urlencoded( { extended: true}));
app.use(cookieParser());

const db = mongoose.connection;
const mongoDBURL = 'mongodb://127.0.0.1/finalProj';

//SCHEMA

var Schema = mongoose.Schema;
var userSchema = new Schema({
    username: String,
    salt: String,
    hash: String,
    highScore: 0
});
var user = mongoose.model('user',userSchema);

var sessionKeys = {};

//Set up default mongoose connection
mongoose.connect(mongoDBURL, {useNewUrlParser: true});
db.on('error', console.error.bind(console, 'MongoDB Connection error: '));

function authenticate(req,res,next){
    if( Object.keys(req.cookies).length > 0) { 
        let u = req.cookies.login.username;
        let key = req.cookies.login.key
        if (Object.keys(sessionKeys[u]).length > 0 && sessionKeys[u][0] == key){
            next();
        } else{
            res.send("Logged Out!");
        }
    } else{
    res.send("Logged Out!");
    }
}

function updateSessions(){
    let now = Date.now();
    console.log(sessionKeys);
    for (e in sessionKeys){
        if (sessionKeys[e][1] < (now - 600000)) {
            delete sessionKeys[e];
        }
    }
}

setInterval(updateSessions, 2000);

app.use('/index.html',authenticate);
app.use('/', express.static('public_html'));

app.get("/get/users/",(req,res) => {
    user.find({}).exec(function(error, results) {
        result = "<pre> " + JSON.stringify(results,null,2) + " </pre>";
        res.send(result);
    });
});

app.post("/add/user/",(req,res) => {
    let contentObj = JSON.parse(req.body.content);
    user.find({username: contentObj.username}).exec(function(error, results) {
        if (results.length == 0) {
            var salt = crypto.randomBytes(64).toString('base64');
            var iterations = 1000;
            crypto.pbkdf2(contentObj.password,salt,iterations,64,'sha512', (err,hash) => {
                if (err) throw err;
                let hStr = hash.toString('base64');
                var account = new user({'username': contentObj.username, 'salt': salt, 'hash':hStr, highScore: 0});
                account.save(function (err) {if (err) console.log (err);});
                res.send('OK');
            });
        } else{
            res.send("BAD");
        } 
    });
});

app.get("/login/:username/:password", (req, res) =>{
    var u = req.params.username;
    user.find({username : u}).exec(function(error, results) {
        if (results.length == 1) {
            let p = req.params.password;
            var salt = results[0].salt;
            var iterations = 1000;
            crypto.pbkdf2(p, salt, iterations, 64,'sha512', (err,hash) => {
                if (err) throw err;
                let hStr = hash.toString('base64');
                if (results[0].hash == hStr) {
                    let sessionKey = Math.floor(Math.random() * 10000);
                    sessionKeys[u] = [sessionKey, Date.now()];
                    res.cookie("login", {username: u, key:sessionKey} ,{maxAge: 600000});
                    res.send("OK");
                } else{
                    res.send("BAD");
                }
            });
        } else{
            res.send("BAD");
        }
    })
})

const port = 3000;
app.listen(port, function() {console.log('server running'); });