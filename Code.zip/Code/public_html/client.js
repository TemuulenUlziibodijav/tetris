/*
Author: 
Date: 
Desc:  the client side javascript used to add users/items into the database
*/

function createUser(){
    let us = $('#username').val();
    let pa = $('#password').val();
    let content = {username:us, password:pa};
    let content_str = JSON.stringify(content);
    $.ajax({
        url: '/add/user/',
        data:{content: content_str},
        method:'POST',
        success: function( result ) {
            if(result == "BAD"){
                $('#errorMessage').html("User already created");
            }else{
                console.log(us);
                $('#login').css("display", "none");
                $('#topScoreBoard').html(us);
            }
        }
    })
}

function userLogin(){
    let us = $('#username').val();
    let pa = $('#password').val();
    $.ajax({
        url: '/login/' + us + '/' + pa,
        method:'GET',
        success: function( result ) {
            if(result == "BAD"){
                $('#errorMessage').html("The password or username was incorrect");
            }else{
                console.log(us);
                $('#login').css("display", "none");
                $('#topScoreBoard').html(us);
            }
        }
    })
}